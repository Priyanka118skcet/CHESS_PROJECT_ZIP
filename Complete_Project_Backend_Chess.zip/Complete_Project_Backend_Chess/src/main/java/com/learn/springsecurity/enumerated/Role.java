package com.learn.springsecurity.enumerated;

public enum Role {
    USER, ADMIN
}
