package com.learn.springsecurity.controller;

import com.learn.springsecurity.model.AdminProfileEntity;
import com.learn.springsecurity.service.AdminProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin-profiles")
public class AdminProfileController {

    private final AdminProfileService adminProfileService;

    @Autowired
    public AdminProfileController(AdminProfileService adminProfileService) {
        this.adminProfileService = adminProfileService;
    }

    @GetMapping("/")
    public ResponseEntity<List<AdminProfileEntity>> getAllAdminProfiles() {
        List<AdminProfileEntity> adminProfiles = adminProfileService.getAllAdminProfiles();
        return new ResponseEntity<>(adminProfiles, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdminProfileEntity> getAdminProfileById(@PathVariable Long id) {
        Optional<AdminProfileEntity> adminProfile = adminProfileService.getAdminProfileById(id);
        return adminProfile.map(entity -> new ResponseEntity<>(entity, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/")
    public ResponseEntity<AdminProfileEntity> addAdminProfile(@RequestBody AdminProfileEntity adminProfile) {
        AdminProfileEntity createdProfile = adminProfileService.addAdminProfile(adminProfile);
        return new ResponseEntity<>(createdProfile, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AdminProfileEntity> updateAdminProfile(@PathVariable Long id, @RequestBody AdminProfileEntity updatedAdminProfile) {
        AdminProfileEntity updatedProfile = adminProfileService.updateAdminProfile(id, updatedAdminProfile);
        return new ResponseEntity<>(updatedProfile, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAdminProfile(@PathVariable Long id) {
        adminProfileService.deleteAdminProfile(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
