package com.learn.springsecurity.service;

import com.learn.springsecurity.model.AdminProfileEntity;
import com.learn.springsecurity.repository.AdminProfileRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service 
public class AdminProfileService {

    private final AdminProfileRepo adminProfileRepo;

    @Autowired
    public AdminProfileService(AdminProfileRepo adminProfileRepo) {
        this.adminProfileRepo = adminProfileRepo;
    }

    public List<AdminProfileEntity> getAllAdminProfiles() {
        return adminProfileRepo.findAll();
    }

    public Optional<AdminProfileEntity> getAdminProfileById(Long id) {
        return adminProfileRepo.findById(id);
    }

    public AdminProfileEntity addAdminProfile(AdminProfileEntity adminProfile) {
        return adminProfileRepo.save(adminProfile);
    }

    public AdminProfileEntity updateAdminProfile(Long id, AdminProfileEntity updatedAdminProfile) {
        if (adminProfileRepo.existsById(id)) {
            updatedAdminProfile.setId(id);
            return adminProfileRepo.save(updatedAdminProfile);
        } else {
            return null;
        }
    }

    public String deleteAdminProfile(Long id) {
        if (adminProfileRepo.existsById(id)) {
            adminProfileRepo.deleteById(id);
            return "Admin profile with ID " + id + " deleted successfully";
        } else {
            return "Admin profile with ID " + id + " not found";
        }
    }
}
